% KP 2019-03: new params

clear ops

%% First, set stuff related to the probe 

ops.root        = saveDirSorting; %destination for saving sorting files
ops.conf        = configFileDir; %location of config files
ops.fbinary     = fullfile(ops.root, datName); 
ops.fproc       = fullfile(ops.root,'temp_wh.dat');
ops.datatype    = 'dat';  % binary ('dat', 'bin') or 'openEphys'
ops.NchanTOT    = 64; % total number of channels
ops.fs          = Info.fs; % sampling rate (24414.0625)
ops.chanMap     = fullfile(ops.conf,['geometry_' whichProbe '.mat']);
ops.chanMapFile = fullfile(ops.conf,['geometry_' whichProbe '.mat']);
probeMap        = load(ops.chanMap);
ops.Nchan       = sum(probeMap.connected>1e-6); % number of active channels 


%% Some params to play with

ops.Nfilt  = 128;  % number of filters(/clusters?) to use (512)
                   % should be a multiple of 32, and 2-4 times more than Nchan

ops.criterionNoiseChannels = 0.4; % fraction of "noise" templates allowed to span all channel groups (see createChannelMapFile for more info). 
%i.e. the number of shanks a template can span is either 1 or >ops.criterionNoiseChannels, but NOT in between. 
%alternatively, if it is a fraction then that level is set iteratively. 
% kcoords is used to forcefully restrict templates to channels in the same
% channel group. An option can be set in the master_file to allow a fraction 
% of all templates to span more channel groups, so that they can capture shared 
% noise across all channels. 
% if ops.criterionNoiseChannels is less than 1, it will be treated as a 
% fraction of the total number of clusters
% if this number is larger than 1, it will be treated as the "effective
% number" of channel groups at which to set the threshold. So if a template
% occupies more than this many channel groups, it will not be restricted to
% a single channel group. 


ops.nt0 = 50; %number of samples for templates (was 33, but too narrow for some wider spikes)

% these options can improve/deteriorate results. when multiple values are 
% provided for an option, the first two are beginning and ending anneal values, 
% the third is the value used in the final pass. 
%The three values correspond to 1) start of optimization 2) end of optimization 3) final template matching and subtraction step.
ops.Th               = [4 8 8];    % threshold for detecting spikes on template-filtered data ([6 12 12]) 
%It's simply a threshold on the convolution of the template (mean cell waveform) with the raw signal.
%MARIUS ops.Th               = [2 12 12] ; %[4 12 12];    % threshold for detecting spikes on template-filtered data ([6 12 12])
ops.lam              = [5 15 15];   % large means amplitudes are forced around the mean ([10 30 30])
%a trade-off between the mean squared error of the raw data reconstruction term  and the squared 
%error between the amplitude of the spike and the mean amplitude for that template. For example, 
%when lam  = Inf, spikes from the same template always have the same amplitude. When lam is set to 
%0, the amplitude from the same template can be anything (but the spatiotemporal shape has to be consistent). 
%MARIUS ops.lam              = [1 5 5];   % large means amplitudes are forced around the mean ([10 30 30])



%% Preprocessing and other basic stuff

ops.Nrank               = 3;    % matrix rank of spike template model (3)
ops.nfullpasses         = 6;    % number of complete passes through data during optimization (6)
ops.nannealpasses       = 4;            % should be less than nfullpasses (4)
ops.momentum            = 1./[20 500];  % start with high momentum and anneal (1./[20 1000])
ops.shuffle_clusters    = 1;            % allow merges and splits during optimization (was 0)
ops.mergeT              = .1;           % upper threshold for merging (.1) 1-correlation.
ops.splitT              = .1;           % lower threshold for splitting (.1). tries to fit bimodal distribution to amps

ops.maxFR               = 10000;  % maximum number of spikes to extract per batch (20000)
ops.fshigh              = 300;    % frequency for high pass filtering
ops.fslow               = 4000;   % frequency for low pass filtering
ops.ntbuff              = 64;     % samples of symmetrical buffer for whitening and spike detection  
                                  % 64 samples is about 2.62 ms at Sanes Lab fs
ops.scaleproc           = 200;    % int16 scaling of whitened data keep this at 200. otherwise gets a lot of zeros
ops.NT                  = 128*1024+ ops.ntbuff;% this is the batch size, very important for memory reasons. 
% should be multiple of 32 (or higher power of 2) + ntbuff

ops.whitening           = 'full'; % dont change this! type of whitening (default 'full', for 'noSpikes' set options for spike detection below)
ops.nSkipCov       = 1; % compute whitening matrix from every N-th batch
ops.whiteningRange = 12; % how many channels to whiten together (Inf for whole probe whitening, should be fine if Nchan<=32)


%% Spike Templates

ops.initialize      = 'no'; %'fromData' or 'no'. If no, puts a filter on each channel,. if yes, biases towards electrodes with more spikes
dd                  = load('PCspikes2.mat'); % you might want to recompute this from your own data.
ops.wPCA            = dd.Wi(:,1:7);   % PCs 

% More options for initializing spikes from data
ops.spkTh           = -4;      % spike threshold in standard deviations (4) 
                     % only used if initialize clusters 'fromData' 
ops.loc_range       = [3  1];  % ranges to detect peaks; plus/minus in time and channel ([3 1])%to be defined as max
ops.long_range      = [30  6]; % ranges to detect isolated peaks ([30 6])%to be defined as a spike
ops.maskMaxChannels = 5;       % how many channels to mask up/down ([5]). like flood fill on KK2
ops.crit            = .65;     % upper criterion for discarding spike repeates (0.65)
ops.nFiltMax        = 10000;   % maximum "unique" spikes to consider (10000)


% Visualization in phy
ops.nNeighPC    = 12; % visualization only (phy): number of channnels to mask the PCs, leave empty to skip (12) 
ops.nNeigh      = 12; % visualization only (phy): number of neighboring templates to retain projections of (12) 


%% Runtime settings

ops.GPU                 = 0; % whether to run this code on an Nvidia GPU (much faster, mexGPUall first)
ops.parfor              = 1; % whether to use parfor to accelerate some parts of the algorithm
ops.verbose             = 1; % whether to print command line progress
ops.showfigures         = 0; % whether to plot figures during optimization
ops.ForceMaxRAMforDat   = 20e9; %20e9;  % maximum RAM the algorithm will try to use


%% For posthoc merges
ops.fracse  = 0.1; % binning step along discriminant axis for posthoc merges (in units of sd)
ops.epu     = Inf;


clear dd;
% batch_path = fullfile(ops.root, 'batches');
% if ~exist(batch_path, 'dir')
%     mkdir(batch_path);
% end